#include "Player.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;
using namespace CocosDenshion;

Player::Player(void)
{
    m_speed = 10;   //��ʼ���ٶ�Ϊ10
}

Player::~Player(void)
{
	this->unscheduleAllCallbacks();
}

Player* Player::create(Sprite* sprite)
{
	Player *player = new Player();
	if (player && player->initWithFile(sprite))
	{
		player->autorelease();
		return player;
	}
	CC_SAFE_DELETE(player);

	return NULL;
}

Player* Player::createFromCsvFileByID(int iHeroID)
{
	Player* player = new Player();
	if (player && player->initFromCsvFileByID(iHeroID))
	{
		player->autorelease();
	}
	else 
	{
		CC_SAFE_DELETE(player);
	}
	return player;
}

bool Player::initWithFile(Sprite* sprite)
{
	bool bRet = false;
	do 
	{
		CC_BREAK_IF(!sprite);
		bindSprite(sprite);          //��sprite����Ա����

		initPhysicsBody();          //��ʼ������body

		bRet = true;
	} while (0);

	return bRet;
}

//��ʼ��������
void Player::initPhysicsBody()
{
	auto playerBody = PhysicsBody::createBox(this->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
            playerBody->setRotationEnable(false);
	        playerBody->getShape(0)->setDensity(1.0f);
	        playerBody->getShape(0)->setMass(50);

	        //���������Ƿ�������ϵ��Ӱ��  
	        playerBody->setGravityEnable(true);

			playerBody->setCategoryBitmask(2);
			playerBody->setContactTestBitmask(4);
			playerBody->setCollisionBitmask(4);

	this->setPhysicsBody(playerBody);

	this->schedule(schedule_selector(Player::updateCallBack), 0.05f);
	//���ñ�־  
	this->setTag(1);
}

bool Player::initFromCsvFileByID(int iHeroID) 
{
	return false;
}

//player���ƶ�����
void Player::movePlayer(int flag)
{
	this->setPosition(this->getPositionX() + m_speed * flag, this->getPositionY());
}

void Player::moveZombie(float dt)
{
	auto jb = JumpBy::create(0.5, Vec2(5, 20), 10, 1);
	jb->setTag(5);
	this->runAction(jb);
}

void Player::updateCallBack(float dt)
{
	//if (this->isDead())
	//{
		//this->removeFromParentAndCleanup(true);
	//}
}


